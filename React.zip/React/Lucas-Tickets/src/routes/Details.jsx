import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { Link } from 'react-router-dom'

function Details(){
    const { id } = useParams() 

    
    const [show, setShow] = useState(null)

  
    const apiUrl = import.meta.env.VITE_SHOWS_API_URL

    
    useEffect(() => { 
        const getShowById = async () => { 
            const response = await fetch(`${apiUrl}/${id}`) 
            const result = await response.json()
            
            if(response.ok) {
            setShow(result) 
}       
        } 

        getShowById()
    }, [id])


    return (
        <>
            <p><Link to="/">← Back to Home</Link></p>

            <div>
                { show && (
                    <>
                        <h2>{show.Title}</h2>
                        <img src={show.Filename} alt={show.Title} width="400" />
                        <p><strong>Description:</strong> {show.Description}</p>
                        <p><strong>Created:</strong> {new Date(show.Createdate).toLocaleString()}</p>
                        <p><strong>Location:</strong> {show.Location}</p>
                        <p><strong>Owner:</strong> {show.Owner}</p>
                        <p><strong>Category:</strong> {show.CategoryTitle} (ID: {show.CategoryID})</p>
                        <p><strong>Show ID:</strong> {show.ShowID}</p>
                    </>
                )}
            </div>

            


            <h3>Payments</h3>

            

            <p><Link to={`/payment/${id}`}>Add a payment</Link></p>
        </>
    )
}

export default Details
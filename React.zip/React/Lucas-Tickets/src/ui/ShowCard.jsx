import { Link } from 'react-router-dom'

function ShowCard(props) {
    return (
        <div className="show-grid-item">
            <Link to={`/details/${props.Showid}`}>
                <img src={props.Filename} alt={props.Title} />
                
            </Link>
        </div>
    )
}

export default ShowCard
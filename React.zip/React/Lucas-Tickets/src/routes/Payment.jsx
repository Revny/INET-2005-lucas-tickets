import { useParams,Link, } from 'react-router-dom'
import { useForm } from 'react-hook-form'


function Payment() {
    const { id } = useParams()
    
     const { register, handleSubmit, formState: { errors }, } = useForm()

      const apiUrl = import.meta.env.VITE_SHOWS_API_URL 
       const onSubmit = async (data) => {
        console.log(data);

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json' 
            },
            body: JSON.stringify(data)
        })

        const result = await response.json()
        console.log(result);

        if (response.ok) {
            

            alert('payment added successfully!')
        } else {
            alert('Failed to add payment.')
        }
    }

    return (
        <>
            <p><Link to={`/details/${id}`}>← Back to show</Link></p>
            <h2>add payment</h2>
           <form onSubmit = {handleSubmit(onSubmit)} className='w-50'>
            <input type='hidden' value={id}
            {...register("ShowID")}/>
          
          

          <div className='mb-3'>
            <label htmlFor="tickets" className="form-label">Number of Tickets</label>
            <input type="number" className="form-control"  id="tickets" 
            {...register("Tickets", { required: true, min: 1 })}
          />

          {errors.Tickets && <span className='text-danger'>must buy at least 1 ticket for payment</span>}
          
          
          </div>

           <div className="mb-3">
          <label htmlFor="name" className="form-label">Name</label>
          <input type="text" className="form-control"  id="name" 
            {...register("Name", { required: true })}
          />
          {errors.Name && <span className="text-danger">your name is required</span>}
        
        </div>

        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input type="email" className="form-control" id="email" 
            {...register("Email", { required: true, pattern: /^\S+@\S+$/i })}
          />
          {errors.Email && <span className="text-danger"> we need a valid email </span>}
        </div>
            
          <div className="mb-3">
          <label htmlFor="phone" className="form-label">Phone</label>
          <input type="tel" className="form-control" id="phone" 
            {...register("Phone", { required: true })}
          />
          {errors.Phone && <span className="text-danger"> A phone number is required</span>}
        </div>

        <div className='mb-3'>
                <label htmlFor='payment' className='form-label'>Payment</label>
                <input type='text' className='form-control' id='payment' name='payment'
                {...register("Payment",{required: true})}/>
                {errors.Payment && <span className='text-danger'>Payment is required</span>}
                
            </div>

            <div className='mb-3'>
                <label htmlFor='paycode' className='form-label'>Paycode</label>
                <input type='text' className='form-control' id='paycode' name='paycode'
                {...register("Paycode",{required: true})}/>
                {errors.Paycode && <span className='text-danger'>paycode is required</span>}
                
            </div>
            <button type="submit" className="btn btn-primary">Submit</button>
            
           

           </form>
        </>
    )
}

export default Payment
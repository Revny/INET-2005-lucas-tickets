
import { useEffect, useState } from 'react'
import ShowCard from '../ui/ShowCard.jsx'



function Home() {
  const [shows, setShows ] = useState ([])

  const apiUrl = import.meta.env.VITE_SHOWS_API_URL

  useEffect (() => {
    const getShows = async () => {
      const response = await fetch(apiUrl)
      const result = await response.json()
       console.log(result)
      if (response.ok){
        setShows(result)
      }
    }
    getShows()

    
  },[])

  return (
    <>
     <div className = "show-grid">
    {
      shows.length >0 && (
        shows.map(show => (
          <div key={show.ShowID}>
             <ShowCard Showid={show.ShowID} Filename={show.Filename} Title={show.Title} />
             </div>
      ))
    )
    }

     </div>
    </>
  )
}
export default Home